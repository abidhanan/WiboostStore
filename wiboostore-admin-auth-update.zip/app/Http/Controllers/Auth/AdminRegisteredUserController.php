<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Models\Role;
use App\Models\User;
use Illuminate\Auth\Events\Registered;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Validation\Rules;
use Illuminate\Validation\ValidationException;
use Illuminate\View\View;

class AdminRegisteredUserController extends Controller
{
    public function create(): View
    {
        return view('auth.admin-register');
    }

    public function store(Request $request): RedirectResponse
    {
        $adminCode = trim((string) config('wiboost.admin_registration_code'));

        if ($adminCode === '') {
            throw ValidationException::withMessages([
                'admin_code' => 'Pendaftaran admin belum diaktifkan. Isi WIBOOST_ADMIN_REGISTER_CODE di file .env hosting.',
            ]);
        }

        $request->validate([
            'name' => ['required', 'string', 'max:255'],
            'email' => ['required', 'string', 'lowercase', 'email', 'max:255', 'unique:'.User::class],
            'whatsapp' => ['nullable', 'string', 'max:20'],
            'password' => ['required', 'confirmed', Rules\Password::defaults()],
            'admin_code' => ['required', 'string'],
        ], [], [
            'name' => 'nama admin',
            'email' => 'alamat email',
            'whatsapp' => 'nomor kontak',
            'password' => 'kata sandi',
            'admin_code' => 'kode admin',
        ]);

        if (! hash_equals($adminCode, (string) $request->admin_code)) {
            throw ValidationException::withMessages([
                'admin_code' => 'Kode admin tidak sesuai.',
            ]);
        }

        Role::query()->updateOrCreate(['id' => 1], ['name' => 'Admin']);
        Role::query()->updateOrCreate(['id' => 2], ['name' => 'Buyer']);

        $user = User::create([
            'name' => $request->name,
            'email' => $request->email,
            'whatsapp' => $request->whatsapp,
            'password' => Hash::make($request->password),
            'role_id' => 1,
        ]);

        event(new Registered($user));

        Auth::login($user);

        return redirect()->route('admin.dashboard');
    }
}
