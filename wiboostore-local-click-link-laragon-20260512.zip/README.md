<p align="center"><a href="https://laravel.com" target="_blank"><img src="https://raw.githubusercontent.com/laravel/art/master/logo-lockup/5%20SVG/2%20CMYK/1%20Full%20Color/laravel-logolockup-cmyk-red.svg" width="400" alt="Laravel Logo"></a></p>

<p align="center">
<a href="https://github.com/laravel/framework/actions"><img src="https://github.com/laravel/framework/workflows/tests/badge.svg" alt="Build Status"></a>
<a href="https://packagist.org/packages/laravel/framework"><img src="https://img.shields.io/packagist/dt/laravel/framework" alt="Total Downloads"></a>
<a href="https://packagist.org/packages/laravel/framework"><img src="https://img.shields.io/packagist/v/laravel/framework" alt="Latest Stable Version"></a>
<a href="https://packagist.org/packages/laravel/framework"><img src="https://img.shields.io/packagist/l/laravel/framework" alt="License"></a>
</p>

## Wiboost Store Ops

### Integrasi yang dipakai

- Tripay untuk pembayaran checkout dan top up saldo.
- Digiflazz untuk produk API seperti PPOB dan top up game.
- OrderSosmed untuk layanan social media order.
- Discord webhook untuk notifikasi order, stok menipis, deposit, auto-refund, dan maintenance report.

### Scheduler penting

Project ini memakai Laravel scheduler. Pastikan server menjalankan:

```bash
php artisan schedule:run
```

Command terjadwal yang aktif:

- `wiboost:auto-refund` setiap 1 jam untuk refund otomatis order lunas yang tetap `pending` lebih dari 24 jam.
- `wiboost:maintenance-report` setiap 2 jam untuk kirim ringkasan operasional ke Discord webhook.

### Command operasional

```bash
php artisan sync:digiflazz
php artisan wiboost:auto-refund
php artisan wiboost:maintenance-report --force
```

### Environment minimum

Isi variabel berikut di `.env`:

- `TRIPAY_API_KEY`
- `TRIPAY_PRIVATE_KEY`
- `TRIPAY_MERCHANT_CODE`
- `DIGIFLAZZ_USERNAME`
- `DIGIFLAZZ_KEY`
- `ORDERSOSMED_API_URL`
- `ORDERSOSMED_API_ID`
- `ORDERSOSMED_API_KEY`
- `ORDERSOSMED_SECRET_KEY`
- `DISCORD_WEBHOOK_URL`

Tambahan tuning maintenance:

- `WIBOOST_PENDING_ALERT_MINUTES`
- `WIBOOST_PROCESSING_ALERT_MINUTES`
- `WIBOOST_MAINTENANCE_MAX_ITEMS`
- `WIBOOST_ADMIN_WHATSAPP`

URL publik untuk callback provider production:

- `WIBOOST_PUBLIC_URL`

Jika `WIBOOST_PUBLIC_URL` dikosongkan, project sekarang otomatis fallback ke `APP_URL`.

Untuk local development normal di Windows, jalankan:

```bat
npm run dev
```

Perintah itu akan menampilkan link Laravel `http://127.0.0.1:8000` di terminal. Ctrl+klik link tersebut untuk membukanya di browser. Kalau PowerShell memblokir `npm.ps1`, pakai `npm.cmd run dev` atau terminal CMD/Laragon Terminal.

Kalau hanya ingin menjalankan Laravel tanpa Vite:

```bat
php artisan serve
```

Kalau ingin langsung dibukakan otomatis ke Chrome, jalankan `run-local-chrome.bat`. Untuk akses dari menu `www` Laragon, gunakan project seperti biasa; root `.htaccess` akan meneruskan request ke folder `public`, dan gambar upload memakai URL relatif `/storage` agar tidak terkunci ke satu host lokal tertentu.

### Checklist menuju live

- Isi stok dan tutorial produk `Aplikasi Premium`.
- Isi harga final, deskripsi final, gambar/logo subkategori, tutorial, dan stok kredensial/nomor.
- Jalankan sync provider sebelum launching:

```bash
php artisan wiboost:setup-catalog
php artisan sync:digiflazz
php artisan sync:ordersosmed
```

- Uji checkout saldo untuk tiap tipe produk: OrderSosmed, Digiflazz, dan akun premium.
- Uji Tripay sandbox/live dari checkout sampai callback sukses.
- Saat deploy produksi, ubah environment ke production: `APP_ENV=production`, `APP_DEBUG=false`, `APP_URL=https://domain-kamu`.
- Pastikan server menjalankan queue worker untuk `QUEUE_CONNECTION=database` dan scheduler `php artisan schedule:run`.
- Jalankan cache produksi setelah `.env` final:

```bash
php artisan config:cache
php artisan route:cache
php artisan view:cache
```

## About Laravel

Laravel is a web application framework with expressive, elegant syntax. We believe development must be an enjoyable and creative experience to be truly fulfilling. Laravel takes the pain out of development by easing common tasks used in many web projects, such as:

- [Simple, fast routing engine](https://laravel.com/docs/routing).
- [Powerful dependency injection container](https://laravel.com/docs/container).
- Multiple back-ends for [session](https://laravel.com/docs/session) and [cache](https://laravel.com/docs/cache) storage.
- Expressive, intuitive [database ORM](https://laravel.com/docs/eloquent).
- Database agnostic [schema migrations](https://laravel.com/docs/migrations).
- [Robust background job processing](https://laravel.com/docs/queues).
- [Real-time event broadcasting](https://laravel.com/docs/broadcasting).

Laravel is accessible, powerful, and provides tools required for large, robust applications.

## Learning Laravel

Laravel has the most extensive and thorough [documentation](https://laravel.com/docs) and video tutorial library of all modern web application frameworks, making it a breeze to get started with the framework. You can also check out [Laravel Learn](https://laravel.com/learn), where you will be guided through building a modern Laravel application.

If you don't feel like reading, [Laracasts](https://laracasts.com) can help. Laracasts contains thousands of video tutorials on a range of topics including Laravel, modern PHP, unit testing, and JavaScript. Boost your skills by digging into our comprehensive video library.

## Laravel Sponsors

We would like to extend our thanks to the following sponsors for funding Laravel development. If you are interested in becoming a sponsor, please visit the [Laravel Partners program](https://partners.laravel.com).

### Premium Partners

- **[Vehikl](https://vehikl.com)**
- **[Tighten Co.](https://tighten.co)**
- **[Kirschbaum Development Group](https://kirschbaumdevelopment.com)**
- **[64 Robots](https://64robots.com)**
- **[Curotec](https://www.curotec.com/services/technologies/laravel)**
- **[DevSquad](https://devsquad.com/hire-laravel-developers)**
- **[Redberry](https://redberry.international/laravel-development)**
- **[Active Logic](https://activelogic.com)**

## Contributing

Thank you for considering contributing to the Laravel framework! The contribution guide can be found in the [Laravel documentation](https://laravel.com/docs/contributions).

## Code of Conduct

In order to ensure that the Laravel community is welcoming to all, please review and abide by the [Code of Conduct](https://laravel.com/docs/contributions#code-of-conduct).

## Security Vulnerabilities

If you discover a security vulnerability within Laravel, please send an e-mail to Taylor Otwell via [taylor@laravel.com](mailto:taylor@laravel.com). All security vulnerabilities will be promptly addressed.

## License

The Laravel framework is open-sourced software licensed under the [MIT license](https://opensource.org/licenses/MIT).
