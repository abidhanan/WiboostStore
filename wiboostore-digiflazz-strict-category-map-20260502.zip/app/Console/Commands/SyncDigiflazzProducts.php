<?php

namespace App\Console\Commands;

use App\Models\Category;
use App\Models\Product;
use App\Services\DigiflazzService;
use App\Support\WiboostCatalog;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Str;

class SyncDigiflazzProducts extends Command
{
    protected $signature = 'sync:digiflazz
        {--match-local-categories : Import hanya produk Digiflazz yang cocok dengan kategori lokal Top Up Game dan Kuota Murah}';

    protected $description = 'Sync produk dari Digiflazz ke database Wiboost dengan mapping kategori otomatis';

    protected ?array $strictDigiflazzCategoryCandidates = null;

    public function handle(DigiflazzService $digiService): int
    {
        $this->info('--- MEMULAI PROSES SINKRONISASI ---');
        $this->info('Mengambil data dari Digiflazz...');
        $matchLocalCategories = (bool) $this->option('match-local-categories');

        $defaultCategoryId = Category::query()->orderBy('id')->value('id');

        if (! $defaultCategoryId) {
            $this->error('Gagal sync: belum ada kategori sama sekali di database.');

            return self::FAILURE;
        }

        $response = $digiService->getPriceList();
        $rawData = $response['raw']['data'] ?? [];

        if (! ($response['success'] ?? false) || ! is_array($rawData) || $rawData === []) {
            $msg = $response['message'] ?? 'Unknown Error';
            $this->error("Gagal ambil data! Pesan: {$msg}");

            return self::FAILURE;
        }

        $products = collect($rawData)
            ->filter(fn ($item) => is_array($item) && filled($item['buyer_sku_code'] ?? null))
            ->values();

        $total = $products->count();

        if ($matchLocalCategories) {
            $this->info('Mode cocok kategori lokal aktif: hanya produk Top Up Game dan Kuota Murah yang sesuai kategori lokal akan disimpan.');
            Product::query()
                ->where('provider_source', 'digiflazz')
                ->update([
                    'is_active' => false,
                    'status' => 'inactive',
                    'updated_at' => now(),
                ]);
            $this->info('Produk Digiflazz lama dinonaktifkan sementara; produk yang cocok akan diaktifkan ulang.');
        }

        $this->info("Ditemukan {$total} produk. Memulai mapping...");

        $bar = $this->output->createProgressBar($total);
        $bar->start();

        $success = 0;
        $failed = 0;
        $skipped = 0;

        foreach ($products as $item) {
            try {
                $topCategorySlug = WiboostCatalog::resolveDigiflazzTopCategorySlug(
                    (string) ($item['product_name'] ?? ''),
                    (string) ($item['brand'] ?? ''),
                    (string) ($item['category'] ?? ''),
                    (string) ($item['desc'] ?? ''),
                );

                if ($topCategorySlug === null) {
                    $skipped++;
                    $bar->advance();
                    continue;
                }

                $hargaModal = (float) ($item['price'] ?? 0);
                $markup = 1.10;
                $hargaJual = ceil(($hargaModal * $markup) / 100) * 100;

                $categoryId = $matchLocalCategories
                    ? $this->resolveStrictLocalCategoryId($item, $topCategorySlug)
                    : $this->resolveDefaultCategoryId($item, $topCategorySlug, $defaultCategoryId);

                if (! $categoryId) {
                    $skipped++;
                    $bar->advance();
                    continue;
                }

                $targetMeta = WiboostCatalog::targetMetaForTopCategory($topCategorySlug) ?? [
                    'label' => null,
                    'placeholder' => null,
                    'hint' => null,
                ];

                $product = Product::firstOrNew([
                    'provider_source' => 'digiflazz',
                    'provider_product_id' => (string) $item['buyer_sku_code'],
                ]);

                if (! $product->exists && blank($product->slug)) {
                    $product->slug = Str::slug((string) ($item['product_name'] ?? 'produk-digiflazz')) . '-' . Str::random(5);
                }

                $isActive = (bool) ($item['buyer_product_status'] ?? false) && (bool) ($item['seller_product_status'] ?? false);

                $product->fill([
                    'category_id' => $categoryId,
                    'provider_id' => 'digiflazz',
                    'provider_source' => 'digiflazz',
                    'process_type' => 'api',
                    'name' => (string) ($item['product_name'] ?? 'Produk Digiflazz'),
                    'description' => (string) ($item['desc'] ?? '-'),
                    'price' => $hargaJual,
                    'provider_product_id' => (string) $item['buyer_sku_code'],
                    'provider_quantity' => 1,
                    'target_label' => $targetMeta['label'],
                    'target_placeholder' => $targetMeta['placeholder'],
                    'target_hint' => $targetMeta['hint'],
                    'is_active' => $isActive,
                    'status' => $isActive ? 'active' : 'inactive',
                    'stock_reminder' => $product->stock_reminder ?? 0,
                ]);

                $product->save();
                $success++;
            } catch (\Throwable $e) {
                $failed++;
                Log::error('Gagal sync SKU ' . ($item['buyer_sku_code'] ?? 'Unknown') . ': ' . $e->getMessage());
            }

            $bar->advance();
        }

        $bar->finish();
        $this->info("\n\n--- HASIL SINKRONISASI ---");
        $this->info("Total Produk: {$total}");
        $this->info("Berhasil   : {$success}");
        $this->info("Dilewati   : {$skipped}");

        if ($failed > 0) {
            $this->warn("Gagal      : {$failed} (Cek storage/logs/laravel.log untuk detail)");
        }

        if ($matchLocalCategories && $success === 0) {
            $this->error('Tidak ada produk Digiflazz yang cocok dengan kategori lokal Top Up Game / Kuota Murah.');
            $this->warn('Pastikan kategori lokal berada di bawah Top Up Game atau Kuota Murah, misalnya Mobile Legends, Free Fire, Axis, Telkomsel, atau Lainnya.');

            return self::FAILURE;
        }

        $this->info('--- SELESAI ---');

        return $failed > 0 ? self::FAILURE : self::SUCCESS;
    }

    protected function resolveDefaultCategoryId(array $item, string $topCategorySlug, int $defaultCategoryId): int
    {
        $subcategorySlug = WiboostCatalog::resolveDigiflazzSubcategorySlug(
            $topCategorySlug,
            (string) ($item['product_name'] ?? ''),
            (string) ($item['brand'] ?? ''),
            (string) ($item['desc'] ?? ''),
        );

        return $subcategorySlug
            ? (Category::query()->where('slug', $subcategorySlug)->value('id')
                ?? $this->categoryIdBySlug($topCategorySlug, $defaultCategoryId))
            : $this->categoryIdBySlug($topCategorySlug, $defaultCategoryId);
    }

    protected function resolveStrictLocalCategoryId(array $item, string $topCategorySlug): ?int
    {
        if (! in_array($topCategorySlug, ['top-up-game', 'kuota-murah'], true)) {
            return null;
        }

        $groupKey = $this->detectStrictDigiflazzGroupKey($topCategorySlug, $item);

        if ($groupKey !== null) {
            $categoryId = $this->findStrictDigiflazzCategoryId($topCategorySlug, $groupKey);

            if ($categoryId !== null) {
                return $categoryId;
            }
        }

        if ($topCategorySlug === 'top-up-game') {
            $categoryId = $this->findStrictDigiflazzCategoryByText($topCategorySlug, $this->normalizeDigiflazzText($this->itemSearchText($item)));

            if ($categoryId !== null) {
                return $categoryId;
            }
        }

        return $this->findStrictDigiflazzCategoryId($topCategorySlug, 'lainnya');
    }

    protected function detectStrictDigiflazzGroupKey(string $topCategorySlug, array $item): ?string
    {
        $text = $this->normalizeDigiflazzText($this->itemSearchText($item));

        foreach ($this->strictDigiflazzGroupAliases($topCategorySlug) as $groupKey => $aliases) {
            if ($groupKey === 'lainnya') {
                continue;
            }

            if ($this->containsAnyKeyword($text, $aliases)) {
                return $groupKey;
            }
        }

        return null;
    }

    protected function findStrictDigiflazzCategoryId(string $topCategorySlug, string $groupKey): ?int
    {
        $aliases = $this->strictDigiflazzGroupAliases($topCategorySlug)[$groupKey] ?? [];
        $bestCandidate = null;
        $bestScore = 0;

        foreach ($this->strictDigiflazzCategoryCandidates($topCategorySlug) as $candidate) {
            if (! $this->containsAnyKeyword($candidate['breadcrumb'], $aliases)) {
                continue;
            }

            $score = (int) $candidate['depth'];

            if ($this->containsAnyKeyword($candidate['own'], $aliases)) {
                $score += 200;
            }

            if ($this->containsAnyKeyword($candidate['parent'], $aliases)) {
                $score += 120;
            }

            if ($score > $bestScore) {
                $bestScore = $score;
                $bestCandidate = $candidate;
            }
        }

        return $bestCandidate ? (int) $bestCandidate['id'] : null;
    }

    protected function findStrictDigiflazzCategoryByText(string $topCategorySlug, string $itemText): ?int
    {
        $bestCandidate = null;
        $bestScore = 0;
        $ignoredTokens = [
            'top', 'up', 'game', 'games', 'voucher', 'diamond', 'diamonds', 'point', 'points',
            'murah', 'lainnya', 'lain', 'paket', 'data', 'kuota', 'internet',
        ];

        foreach ($this->strictDigiflazzCategoryCandidates($topCategorySlug) as $candidate) {
            if ($this->containsAnyKeyword($candidate['own'], $this->strictDigiflazzGroupAliases($topCategorySlug)['lainnya'] ?? [])) {
                continue;
            }

            $tokens = collect(explode(' ', trim($candidate['own'])))
                ->filter(fn (string $token) => strlen($token) >= 3)
                ->reject(fn (string $token) => in_array($token, $ignoredTokens, true))
                ->unique()
                ->values();

            if ($tokens->isEmpty()) {
                continue;
            }

            $score = $tokens
                ->filter(fn (string $token) => str_contains($itemText, ' ' . $token . ' '))
                ->count();

            if ($score <= 0) {
                continue;
            }

            $score = ($score * 100) + (int) $candidate['depth'];

            if ($score > $bestScore) {
                $bestScore = $score;
                $bestCandidate = $candidate;
            }
        }

        return $bestCandidate ? (int) $bestCandidate['id'] : null;
    }

    protected function strictDigiflazzCategoryCandidates(string $topCategorySlug): array
    {
        if ($this->strictDigiflazzCategoryCandidates === null) {
            $this->strictDigiflazzCategoryCandidates = [];
        }

        if (array_key_exists($topCategorySlug, $this->strictDigiflazzCategoryCandidates)) {
            return $this->strictDigiflazzCategoryCandidates[$topCategorySlug];
        }

        $rootAliases = $this->strictDigiflazzRootAliases($topCategorySlug);

        $this->strictDigiflazzCategoryCandidates[$topCategorySlug] = Category::query()
            ->with('parent.parent.parent.parent')
            ->get()
            ->map(function (Category $category) {
                $parent = $category->parent;
                $root = $category;

                while ($root->parent) {
                    $root = $root->parent;
                }

                return [
                    'id' => $category->id,
                    'own' => $this->normalizeDigiflazzText($category->name . ' ' . $category->slug),
                    'parent' => $parent ? $this->normalizeDigiflazzText($parent->name . ' ' . $parent->slug) : '',
                    'breadcrumb' => $this->normalizeDigiflazzText($category->breadcrumb_name . ' ' . $category->slug),
                    'root' => $this->normalizeDigiflazzText($root->name . ' ' . $root->slug),
                    'depth' => $category->depth,
                ];
            })
            ->filter(fn (array $candidate) => (int) $candidate['depth'] > 0)
            ->filter(fn (array $candidate) => $this->containsAnyKeyword($candidate['root'], $rootAliases))
            ->values()
            ->all();

        return $this->strictDigiflazzCategoryCandidates[$topCategorySlug];
    }

    protected function strictDigiflazzRootAliases(string $topCategorySlug): array
    {
        return match ($topCategorySlug) {
            'top-up-game' => [' top up game ', ' topup game ', ' game ', ' games '],
            'kuota-murah' => [' kuota murah ', ' kuota ', ' paket data ', ' data internet '],
            default => [' ' . $topCategorySlug . ' '],
        };
    }

    protected function strictDigiflazzGroupAliases(string $topCategorySlug): array
    {
        if ($topCategorySlug === 'kuota-murah') {
            return [
                'axis' => [' axis ', ' aigo '],
                'telkomsel' => [' telkomsel ', ' tsel ', ' by u ', ' byu ', ' kartu as ', ' simpati '],
                'tri' => [' tri ', ' three '],
                'indosat' => [' indosat ', ' im3 ', ' mentari '],
                'smartfren' => [' smartfren '],
                'xl' => [' xl ', ' xtra ', ' xl axiata '],
                'lainnya' => [' lainnya ', ' lain ', ' other ', ' others '],
            ];
        }

        return [
            'mobile-legends' => [' mobile legends ', ' mobilelegend ', ' mlbb ', ' ml '],
            'free-fire' => [' free fire ', ' freefire ', ' ff '],
            'pubg-mobile' => [' pubg ', ' pubg mobile '],
            'valorant' => [' valorant ', ' vp '],
            'arena-of-valor' => [' arena of valor ', ' aov '],
            'genshin-impact' => [' genshin ', ' genshin impact '],
            'honkai-star-rail' => [' honkai star rail ', ' hsr '],
            'zenless-zone-zero' => [' zenless ', ' zenless zone zero ', ' zzz '],
            'call-of-duty-mobile' => [' call of duty ', ' codm ', ' cod mobile '],
            'point-blank' => [' point blank ', ' pb cash '],
            'roblox' => [' roblox ', ' robux '],
            'steam' => [' steam '],
            'google-play' => [' google play '],
            'higgs-domino' => [' higgs domino ', ' domino '],
            'lainnya' => [' lainnya ', ' lain ', ' other ', ' others '],
        ];
    }

    protected function itemSearchText(array $item): string
    {
        return implode(' ', array_filter([
            $item['brand'] ?? null,
            $item['category'] ?? null,
            $item['product_name'] ?? null,
            $item['buyer_sku_code'] ?? null,
            $item['desc'] ?? null,
        ]));
    }

    protected function containsAnyKeyword(string $text, array $keywords): bool
    {
        foreach ($keywords as $keyword) {
            if (str_contains($text, $keyword)) {
                return true;
            }
        }

        return false;
    }

    protected function normalizeDigiflazzText(string $text): string
    {
        $text = html_entity_decode($text, ENT_QUOTES | ENT_HTML5, 'UTF-8');
        $text = Str::lower($text);
        $text = preg_replace('/[^\pL\pN]+/u', ' ', $text) ?? $text;

        return ' ' . trim(preg_replace('/\s+/u', ' ', $text) ?? $text) . ' ';
    }

    protected function categoryIdBySlug(string $slug, int $fallbackId): int
    {
        return Category::query()->where('slug', $slug)->value('id') ?? $fallbackId;
    }
}
